/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "esp8266.h"
#include "dht11.h"
#include "buzz.h"
#include "GP2Y.h"
#include "math.h"
#include "oled.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint16_t adc_buff[2];
uint8_t uart_data;

uint8_t humidity, temp;
uint8_t co1, formaldehyde;
uint16_t pm2_5;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)//当定时器的周期时间到达时被调用
{
	if (htim->Instance == htim2.Instance) {
		buzz_Handler();
		
		if (temp > 40 || humidity > 40 || co1 > 87 || formaldehyde > 100 || pm2_5 > 200) {
			buzz_didi(1);
			__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, 500);
		} else {
			__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, fs_speed);
		}
	}	
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)//当UART接收完成时被调用
{
	if (huart->Instance == huart1.Instance) {
		esp8266Rx_ForUart(uart_data);
		HAL_UART_Receive_IT(&huart1, &uart_data, 1);
	}	
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_USART1_UART_Init();
  MX_TIM3_Init();
  MX_TIM2_Init();
  MX_ADC2_Init();
  /* USER CODE BEGIN 2 */
	HAL_TIM_Base_Start(&htim3);
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
	HAL_UART_Receive_IT(&huart1, &uart_data, 1);
	buzz_didi(2);
	
	OLED_Init();
	GP2Y_Init();
	esp8266_init();
	oled_showInfor();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		/* 获取温湿 */
		if (DHT_Read()) {
			humidity = dht11_Data[0]+(dht11_Data[1]/10.f);
			temp = dht11_Data[2]+(dht11_Data[3]/10.f);
		}
	
		/* 气体浓度传感 */
		static uint8_t whodoing=0;
		if (whodoing) {
			HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adc_buff, 4);
			whodoing=0;
		} else {
			co1 = adc_buff[0] / 4096.f * 100.f;
			float formaldehyde_adc = adc_buff[1] / 4096.f * 3.3f;
			formaldehyde = ((-1.095) + formaldehyde_adc * 0.627f) * 100;
			whodoing=1;
		}
	
		Get_GP2Y_Average();
		pm2_5 = (uint16_t)(GP2Y.GP2Y_Value_Average * 10);
		
		/* 显示到屏幕上 */
		/* 显示温度 */
		OLED_ShowNum(1, 6, temp/10, 1);
		OLED_ShowNum(1, 6+1, temp%10, 1);
		
		OLED_ShowNum(1, 12+2, humidity/10, 1);
		OLED_ShowNum(1, 12+3, humidity%10, 1);
		
		OLED_ShowNum(2, 6, co1/10, 1);
		OLED_ShowNum(2, 6+1, co1%10, 1);
		
		OLED_ShowNum(3, 10, 		(formaldehyde/100)%10, 1);
		OLED_ShowNum(3, 10+1, 	(formaldehyde/10)%10, 1);
		OLED_ShowNum(3, 10+2, 	formaldehyde%10, 1);
		
		OLED_ShowNum(4, 7, 		(pm2_5/100)%10, 1);
		OLED_ShowNum(4, 7+1, 	(pm2_5/10)%10, 1);
		OLED_ShowNum(4, 7+2, 	pm2_5%10, 1);
		
		
		/* 通过wifi发送出去*/
		esp8266_uint16(0xf1, temp<<8  | humidity);
		esp8266_uint16(0xf2, co1<<8 | formaldehyde);
		esp8266_uint16(0xf3, pm2_5);
		HAL_Delay(1);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;//使用外部高速晶体振荡器（HSE）作为时钟源。
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;//启用外部高速晶体振荡器。
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;//设置外部高速晶体振荡器的预分频值为1，表示不进行预分频。
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;//启用内部高速时钟（HSI）。
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;//启用锁相环（PLL）。
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;//将外部高速晶体振荡器作为锁相环的输入时钟源。
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;//设置锁相环的倍频系数为9，表示将输入时钟频率乘以9倍。
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
	//主时钟（HCLK）、系统时钟（SYSCLK）、APB1时钟（PCLK1）和APB2时钟（PCLK2）
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)//&RCC_ClkInitStruct是一个指向时钟配置结构体的指针，FLASH_LATENCY_2表示将Flash存储器的等待周期设置为2个时钟周期
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
