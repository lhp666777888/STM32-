#include "GP2Y.h"

GP2Y_t GP2Y;

/**
 * @brief  微妙级延时
 * @param  void
 * @retval void
 */
static void Delay_us(uint16_t us) //微秒延时
{    
	while(us--)
	{
		int myus = 72;
		while(myus--);
	}
}

/**
 * @brief  初始化
 * @param  void
 * @retval void
 */
void GP2Y_Init(void)
{
	GP2Y(1); //置高电平，内部红外二极管初始状态为灭
}

/**
 * @brief  获取GP2Y值
 * @param  void
 * @retval void
 */
uint16_t GP2Y_GetValue(void)
{
	HAL_ADCEx_Calibration_Start(GP2Y_ADC);    //AD校准
	HAL_ADC_Start(GP2Y_ADC);    //启动ADC转换
	HAL_ADC_PollForConversion(GP2Y_ADC,0x10);  //等待转换完成
	
	GP2Y(0); //置低电平,打开红外二极管	
	Delay_us(280);
	
	GP2Y.ADC_Value = HAL_ADC_GetValue(GP2Y_ADC);	//获取转换值
	
	GP2Y.PM_Value = 0.17*GP2Y.ADC_Value - 0.1;
	GP2Y.GP2Y_Value = (( (GP2Y.Voltage+1)*1000 )/10);
	
	Delay_us(40);
	GP2Y(1); //置高电平,关闭红外二极管
	Delay_us(9680);
	return GP2Y.PM_Value;
}

/**
 * @brief  获取GP2Y平均值
 * @param  单位 ug/m3
 * @retval void
 */
void Get_GP2Y_Average(void)
{
	GP2Y.GP2Y_Value_Average += (GP2Y_GetValue() - GP2Y.GP2Y_Value_Average) * 0.03f;
} 


