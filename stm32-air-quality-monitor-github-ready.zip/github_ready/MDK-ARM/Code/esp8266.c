#include "esp8266.h"

int fs_speed = 0;
Deer_t _Deer = {
	.step = 0,
	.cnt  = 0,
};
void uart1_txBuff(uint8_t txbuff[], uint8_t size);

void uart1_txString(char *txSrting)
{
	uart1_txBuff((uint8_t *)txSrting, strlen((char *)txSrting));
}

void uart1_txBuff(uint8_t txbuff[], uint8_t size)
{
	for (uint8_t i=0; i < size; i++) {
		HAL_UART_Transmit(&huart1, &txbuff[i], 1, 0xff);
	}
}

/**
 * @brief  初始化esp8266
 * @param  
 * @retval 无
 */
void esp8266_init(void)
{
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);
	HAL_Delay(1000);
	
	uart1_txString("AT+RST\r\n");
	HAL_Delay(1600);
	
	uart1_txString("AT+CWMODE_DEF=2\r\n");
	HAL_Delay(600);
	
	uart1_txString("AT+CWSAP_DEF=\"LiuHaipeng\",\"12345678\",5,3\r\n");
	HAL_Delay(600);
	
	uart1_txString("AT+CIPMODE=0\r\n");
	HAL_Delay(600);
	
	uart1_txString("AT+CIPMUX=1\r\n");
	HAL_Delay(600);
	
	uart1_txString("AT+CIPSERVER=1,3303\r\n");
	HAL_Delay(600);
}

/**
 * @brief  通信发送底层函数
 * @param  void
 * @retval void
 */
void eps8266_tx(uint8_t fun, uint8_t *data, uint8_t datalen)
{
		
		 uint8_t SendBuff[32];
   
    uint8_t len = 0;

    /* 帧头 */
    SendBuff[len++] = 0xFD;
    SendBuff[len++] = 0xDF;

    /* 总长度 先占位 */
    SendBuff[len++] = 0;

    /* 功能帧 */
    SendBuff[len++] = fun;

    /* 数据 */
    for (int max = (datalen + len), now = len; len < max; len++) {
        SendBuff[len] = data[len - now];
    }

    /* 获取实际长度 */
    SendBuff[2] = len;

    /* 校验位 */
    SendBuff[len] = 0;
    for (int i = 0; i < len; i++) {
        SendBuff[len] += SendBuff[i];
    }
		
//		uart1_txu8(SendBuff[2]);
//		uart1_txString("\r\n");
		
		uart1_txBuff(SendBuff, len+1);
}

/**
 * @brief  发送16位数据
 * @param  void
 * @retval void
 */
void esp8266_uint16(uint8_t fun, uint16_t data)
{
	uint8_t txdata[2];
	uart1_txString("AT+CIPSENDBUF=0,26\r\n");
	
	HAL_Delay(1);
	
	txdata[0] = (uint8_t)(data >> 8);
	txdata[1] = (uint8_t)data;

	eps8266_tx(fun, txdata, 2);
}

/**
 * @brief  发送8位数据
 * @param  void
 * @retval void
 */
void esp8266_uint8(uint8_t fun, uint8_t data)
{
	uart1_txString("AT+CIPSENDBUF=0,26\r\n");
	
	HAL_Delay(1);

	eps8266_tx(fun, &data, 1);
}

/**
 * @brief  根据上位机命令做出对应响应
 * @param  void
 * @retval void
 */
void DeerSwitch(void)
{
	switch(_Deer.buff[3])
	{
		case 0xE1:	/* 按键1事件 */
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
			break;
		case 0xE2:	/* 按键2事件 */
			HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
			break;
		case 0xE3:	/* 按键3事件 */
			fs_speed = 500;
			//__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, 500);
			break;
		case 0xE4:	/* 按键4事件 */
			fs_speed = 0;
			//__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1, 0);
			break;
	}
}

/**
* @brief  上位机指令解析 
 * @param  void
 * @retval void
 */
void DeerParsing(void)
{
	uint8_t ack = 0;
	
	for (int i=0; i < _Deer.rxlen; i++) {
		ack += _Deer.buff[i];
	}
	
	if (ack == _Deer.buff[_Deer.rxlen]) {
		DeerSwitch();
	}	
}

/**
 * @brief  通过串口接收命令
 * @param  void
 * @retval void
 */
//内部使用了一个 _Deer 结构体变量来保存接收状态和数据缓冲区等信息。


void esp8266Rx_ForUart(uint8_t data)
{

	switch(_Deer.step) {
		case 0://当 _Deer.step 为 0 时，表示接收到数据包的起始标志，即 0xFD。
			_Deer.cnt = 0;
			_Deer.buff[_Deer.cnt++] = data;
			if (data == 0xFD) {
				_Deer.step = 1;
			}
			break;
		case 1://当 _Deer.step 为 1 时，表示正在接收数据包内容。
			_Deer.buff[_Deer.cnt++] = data;
			if (data == 0xDF) {
				_Deer.step = 2;
			} else {
				_Deer.step = 0;
			}
			break;
		case 2://当 _Deer.step 为 2 时，表示接收到了数据包长度信息。
			_Deer.buff[_Deer.cnt++] = data;
		
			if (_Deer.cnt - 1 == 2) {
				_Deer.rxlen = data;
			}
			
			if (_Deer.cnt > _Deer.rxlen) {
				_Deer.step = 3;//当 _Deer.step 为 3 时，表示接收完整个数据包，可以进行解析处理。
				_Deer.cnt = 0;
			}
			
			break;
			
		default :
		{};
	}
	
	if (_Deer.step == 3) {
		_Deer.step = 0;
		DeerParsing();
	}
}
/******************* (C) COPYRIGHT 2022 XXX*****END OF FILE************/
