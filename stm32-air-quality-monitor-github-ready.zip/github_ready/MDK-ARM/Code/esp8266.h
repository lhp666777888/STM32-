/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __ESP8266_H
#define __ESP8266_H

#include "usart.h"
#include "string.h"
#include "tim.h"

typedef struct{
	uint8_t step;
	uint8_t cnt;
	uint8_t buff[32];
	uint8_t rxlen;
}Deer_t;


void esp8266_init(void);
void esp8266_uint16(uint8_t fun, uint16_t data);
void esp8266_uint8(uint8_t fun, uint8_t data);
void esp8266Rx_ForUart(uint8_t data);

extern int fs_speed;
#endif /* __ESP8266_H */

/******************* (H) COPYRIGHT 2024 XXX*****END OF FILE************/

