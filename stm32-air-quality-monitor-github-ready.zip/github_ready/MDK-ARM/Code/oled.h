#ifndef __OLED_H__
#define __OLED_H__

#include "gpio.h"

#define OLED_CS_GPIO		GPIOB
#define OLED_DC_GPIO		GPIOB
#define OLED_RES_GPIO		GPIOB
#define OLED_D1_GPIO		GPIOA
#define OLED_D0_GPIO		GPIOA

#define OLED_CS_GPIO_PIN		GPIO_PIN_5
#define OLED_DC_GPIO_PIN		GPIO_PIN_4
#define OLED_RES_GPIO_PIN		GPIO_PIN_3
#define OLED_D1_GPIO_PIN		GPIO_PIN_15
#define OLED_D0_GPIO_PIN		GPIO_PIN_12

#define OLED_CS(x)			HAL_GPIO_WritePin(OLED_CS_GPIO, OLED_CS_GPIO_PIN, 	(GPIO_PinState)x)
#define OLED_DC(x)			HAL_GPIO_WritePin(OLED_DC_GPIO, OLED_DC_GPIO_PIN, 	(GPIO_PinState)x)
#define OLED_RES(x)			HAL_GPIO_WritePin(OLED_RES_GPIO, OLED_RES_GPIO_PIN, (GPIO_PinState)x)
#define OLED_D1(x)			HAL_GPIO_WritePin(OLED_D1_GPIO, OLED_D1_GPIO_PIN,	 	(GPIO_PinState)x)
#define OLED_D0(x)			HAL_GPIO_WritePin(OLED_D0_GPIO, OLED_D0_GPIO_PIN, 	(GPIO_PinState)x)


void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void oled_showInfor(void);

#endif
