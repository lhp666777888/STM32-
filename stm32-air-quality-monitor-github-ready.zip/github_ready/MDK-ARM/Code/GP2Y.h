#ifndef __GP2Y_H
#define __GP2Y_H

#include "main.h"
#include "tim.h"
#include "adc.h"

#define GP2Y_ADC		&hadc2

#define GP2Y_GPIO GPIOA
#define GP2Y_PIN  GPIO_PIN_4
#define GP2Y(x) HAL_GPIO_WritePin(GP2Y_GPIO,GP2Y_PIN,(GPIO_PinState)(x))

typedef struct
{
	float Voltage;
	float GP2Y_Value_Average;
	float PM_Value;
	float GP2Y_Value;
	
	uint16_t ADC_Value;

}GP2Y_t;

extern GP2Y_t GP2Y;

void GP2Y_Init(void);
void Get_GP2Y_Average(void);

#endif 


