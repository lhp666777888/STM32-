/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BUZZ_H
#define __BUZZ_H

#include "gpio.h"

void buzz_didi(int didi);
void buzz_Handler(void);
#endif /* __BUZZ_H */

/******************* (H) COPYRIGHT 2024 LIUZHOUGONGXUEYUAN*****END OF FILE************/

