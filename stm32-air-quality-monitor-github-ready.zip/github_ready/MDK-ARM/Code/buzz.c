#include "buzz.h"
int cnt;
int num;

/**
 * @brief  蜂鸣器响
 * @param  
 * @retval 无
 */
void buzz_didi(int didi)
{
	if (num > 0) {
		return;
	}
	
	num = didi;	
}

/**
 * @brief  无延时蜂鸣器服务函数
 * @param  
 * @retval 无
 */
void buzz_Handler(void)
{
	if (num > 0) {
		if (cnt < 10) {
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
		} else if (cnt < 20) {
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
		} else {
			cnt = 0;
			num--;
		}
		
		cnt++;
	}	
}
/******************* (C) COPYRIGHT 2022 LIUZHOUGONGXUEYUAN*****END OF FILE************/
